#include "mdecoderclass.h"

#include "stdlib.h"
#include "stdio.h"
#include <cstdio>



/* packet queue handling */
static void packet_queue_init(PacketQueue *q)
{
    memset(q, 0, sizeof(PacketQueue));
    q->abort_request = 1;
}

static void packet_queue_flush(PacketQueue *q)
{
    AVPacketList *pkt, *pkt1;
    for (pkt = q->first_pkt; pkt != NULL; pkt = pkt1) {
        pkt1 = pkt->next;
        av_free_packet(&pkt->pkt);
        av_freep(&pkt);
    }
    q->last_pkt = NULL;
    q->first_pkt = NULL;
    q->nb_packets = 0;
    q->size = 0;
}

static void packet_queue_destroy(PacketQueue *q)
{
    packet_queue_flush(q);
}

static void packet_queue_abort(PacketQueue *q)
{
    q->abort_request = 1;

}

static void packet_queue_start(PacketQueue *q)
{
    q->abort_request = 0;
    packet_queue_put_private(q, &flush_pkt);
}

/* return < 0 if aborted, 0 if no packet and > 0 if packet.  */
static int packet_queue_get(PacketQueue *q, AVPacket *pkt, int block)
{
    AVPacketList *pkt1;
    int ret;

    for (;;) {
        if (q->abort_request) {
            ret = -1;
            break;
        }
        pkt1 = q->first_pkt;
        if (pkt1) {
            q->first_pkt = pkt1->next;
            if (!q->first_pkt)
                q->last_pkt = NULL;
            q->nb_packets--;
            q->size -= pkt1->pkt.size + sizeof(*pkt1);
            *pkt = pkt1->pkt;
            av_free(pkt1);
            ret = 1;
            break;
        } else if (!block) {
            ret = 0;
            break;
        } else {
        }
    }

    return ret;
}

typedef struct VideoState {
    AVInputFormat *iformat;
    int no_background;
    int abort_request;
    int force_refresh;
    int paused;
    int last_paused;
    int que_attachments_req;
    int seek_req;
    int seek_flags;
    int64_t seek_pos;
    int64_t seek_rel;
    int read_pause_return;
    AVFormatContext *ic;

    int audio_stream;

    int av_sync_type;
    double external_clock; /* external clock base */
    int64_t external_clock_time;

    double audio_clock;
    double audio_diff_cum; /* used for AV difference average computation */
    double audio_diff_avg_coef;
    double audio_diff_threshold;
    int audio_diff_avg_count;
    AVStream *audio_st;
    //    PacketQueue audioq;
    int audio_hw_buf_size;
    DECLARE_ALIGNED(16,uint8_t,audio_buf2)[AVCODEC_MAX_AUDIO_FRAME_SIZE * 4];
    uint8_t silence_buf[AUDIO_BUFFER_SIZE];
    uint8_t *audio_buf;
    uint8_t *audio_buf1;
    unsigned int audio_buf_size; /* in bytes */
    int audio_buf_index; /* in bytes */
    int audio_write_buf_size;
    AVPacket audio_pkt_temp;
    AVPacket audio_pkt;
    //    struct AudioParams audio_src;
    //    struct AudioParams audio_tgt;
    struct SwrContext *swr_ctx;
    double audio_current_pts;
    double audio_current_pts_drift;
    int frame_drops_early;
    int frame_drops_late;
    AVFrame *frame;

    enum ShowMode {
        SHOW_MODE_NONE = -1, SHOW_MODE_VIDEO = 0, SHOW_MODE_WAVES, SHOW_MODE_RDFT, SHOW_MODE_NB
    } show_mode;
    int16_t sample_array[SAMPLE_ARRAY_SIZE];
    int sample_array_index;
    int last_i_start;
    //    RDFTContext *rdft;
    int rdft_bits;
    int xpos;

    int subtitle_stream;
    int subtitle_stream_changed;
    AVStream *subtitle_st;

    //    SubPicture subpq[SUBPICTURE_QUEUE_SIZE];
    int subpq_size, subpq_rindex, subpq_windex;

    double frame_timer;
    double frame_last_pts;
    double frame_last_duration;
    double frame_last_dropped_pts;
    double frame_last_returned_time;
    double frame_last_filter_delay;
    int64_t frame_last_dropped_pos;
    double video_clock;             // pts of last decoded frame / predicted pts of next decoded frame
    int video_stream;
    AVStream *video_st;
    PacketQueue videoq;
    double video_current_pts;       // current displayed pts (different from video_clock if frame fifos are used)
    double video_current_pts_drift; // video_current_pts - time (av_gettime) at which we updated video_current_pts - used to have running video pts
    int64_t video_current_pos;      // current displayed file pos
    //    VideoPicture pictq[VIDEO_PICTURE_QUEUE_SIZE];
    int pictq_size, pictq_rindex, pictq_windex;

#if !CONFIG_AVFILTER
    struct SwsContext *img_convert_ctx;
#endif

    char filename[1024];
    int width, height, xleft, ytop;
    int step;

#if CONFIG_AVFILTER
    AVFilterContext *in_video_filter;   // the first filter in the video chain
    AVFilterContext *out_video_filter;  // the last filter in the video chain
    int use_dr1;
    FrameBuffer *buffer_pool;
#endif

    int refresh;
    int last_video_stream, last_audio_stream, last_subtitle_stream;
} VideoState;

static int get_video_frame(MDecoderClass *is, AVFrame *frame, int64_t *pts, AVPacket *pkt)
{
    int got_picture, i;

     if (packet_queue_get(&is->videoq, pkt, 1) < 0)
         return -1;

     if (pkt->data == is->flush_pkt.data) {
         avcodec_flush_buffers(is->video_st->codec);

         // Make sure there are no long delay timers (ideally we should just flush the que but thats harder)
         for (i = 0; i < VIDEO_PICTURE_QUEUE_SIZE; i++) {
             is->pictq[i].skip = 1;
         }
//         while (is->pictq_size && !is->videoq.abort_request) {
//         }

         is->video_current_pos = -1;
         is->frame_last_pts = AV_NOPTS_VALUE;
         is->frame_last_duration = 0;
         is->frame_timer = (double)av_gettime() / 1000000.0;
         is->frame_last_dropped_pts = AV_NOPTS_VALUE;

         return 0;
     }

     if(avcodec_decode_video2(is->video_st->codec, frame, &got_picture, pkt) < 0)
         return 0;

     if (got_picture) {
         int ret = 1;

         if (is->decoder_reorder_pts == -1) {
             *pts = av_frame_get_best_effort_timestamp(frame);
         } else if (decoder_reorder_pts) {
             *pts = frame->pkt_pts;
         } else {
             *pts = frame->pkt_dts;
         }

         if (*pts == AV_NOPTS_VALUE) {
             *pts = 0;
         }

//         if (((is->av_sync_type == AV_SYNC_AUDIO_MASTER && is->audio_st) || is->av_sync_type == AV_SYNC_EXTERNAL_CLOCK) &&
//              (framedrop>0 || (framedrop && is->audio_st))) {

//             if (is->frame_last_pts != AV_NOPTS_VALUE && *pts) {
//                 double clockdiff = get_video_clock(is) - get_master_clock(is);
//                 double dpts = av_q2d(is->video_st->time_base) * *pts;
//                 double ptsdiff = dpts - is->frame_last_pts;
//                 if (fabs(clockdiff) < AV_NOSYNC_THRESHOLD &&
//                      ptsdiff > 0 && ptsdiff < AV_NOSYNC_THRESHOLD &&
//                      clockdiff + ptsdiff - is->frame_last_filter_delay < 0) {
//                     is->frame_last_dropped_pos = pkt->pos;
//                     is->frame_last_dropped_pts = dpts;
//                     is->frame_drops_early++;
//                     ret = 0;
//                 }
//             }
//         }

         return ret;
     }
     return 0;
}

//����
DWORD DecodeThread(PVOID pContext)
{
    MDecoderClass *pThis = (MDecoderClass*)pContext;
    pThis->m_moveToThread(pThis->m_pContext);
    unsigned char *frameBuf = (unsigned char *)malloc(DISPLAYBUFZISE);
    memset(frameBuf, 0, DISPLAYBUFZISE);
    AVPacket packet;
    int frameFinished;
    int i =0;
    //����Ƶ֡
    while(true)
    {
        if (av_read_frame(pThis->m_pFormatCtx, &packet)<0)
            break;
        memset(frameBuf, 0, DISPLAYBUFZISE);
        while (pThis->m_pause)
            ::Sleep(50);
        if (pThis->m_stop)
            break;
        if(packet.stream_index == pThis->videoStream)
        {
            int result;
            avcodec_decode_video2(pThis->m_pCodecCtx,pThis->m_pFrame,&frameFinished,
                                  &packet);
            // Did we get a video frame?
            if(frameFinished)
            {
                //���õ���YUV����ת����RGB����
                if (pThis->img_convert_ctx)
                    pThis->img_convert_ctx = sws_getCachedContext(pThis->img_convert_ctx,pThis->m_pCodecCtx->width,
                                                                  pThis->m_pCodecCtx->height,
                                                                  pThis->m_pCodecCtx->pix_fmt,
                                                                  pThis->m_pCodecCtx->width,
                                                                  pThis->m_pCodecCtx->height,
                                                                  AV_PIX_FMT_RGB24,
                                                                  SWS_BICUBIC,NULL,
                                                                  NULL,NULL);
                else
                    pThis->img_convert_ctx = sws_getContext(pThis->m_pCodecCtx->width,
                                                            pThis->m_pCodecCtx->height,
                                                            pThis->m_pCodecCtx->pix_fmt,
                                                            pThis->m_pCodecCtx->width,
                                                            pThis->m_pCodecCtx->height,
                                                            AV_PIX_FMT_RGB24,
                                                            SWS_BICUBIC,NULL,
                                                            NULL,NULL);
                result = sws_scale(pThis->img_convert_ctx,
                                   (const uint8_t* const*)pThis->m_pFrame->data,
                                   pThis->m_pFrame->linesize,
                                   0,
                                   pThis->m_pCodecCtx->height,
                                   pThis->m_pFrameRGB->data,
                                   pThis->m_pFrameRGB->linesize);

                //����Ҫ����linesize
                pThis->m_displayFun(pThis->m_pFrameRGB->data[0], pThis->m_numBytes, pThis->m_pCodecCtx->width, pThis->m_pCodecCtx->height, pThis->m_pContext);

                i++;
            }
        }
        //�Ƿ��������������Կ���֡��?
        ::Sleep(10);
    }
    // Free the packet that was allocated by av_read_frame
    pThis->m_removeFromThread(pThis->m_pContext);
    av_free_packet(&packet);
    free(frameBuf);
    return 0;
}

MDecoderClass::MDecoderClass() :
    m_decodeThreadHandle(NULL),
    m_pFrame(NULL),
    m_pFrameRGB(NULL),
    m_pFormatCtx(NULL),
    m_buffer(NULL),
    img_convert_ctx(NULL),
    m_pause(false),
    m_stop(false),
    m_displayFun(NULL),
    m_moveToThread(NULL),
    m_removeFromThread(NULL),
    m_pContext(NULL)
{
    avcodec_register_all();
#if CONFIG_AVDEVICE
    avdevice_register_all();
#endif
#if CONFIG_AVFILTER
    avfilter_register_all();
#endif
    av_register_all();
    avformat_network_init();

    decoder_reorder_pts = -1;
    av_init_packet(&flush_pkt);
    flush_pkt.data = (char *)(intptr_t)"FLUSH";
}

MDecoderClass::~MDecoderClass()
{
    m_displayFun = NULL;
    m_pContext = NULL;
    threadTerminate();
    freeBuffer();
    this->m_moveToThread = NULL;
    this->m_removeFromThread = NULL;
}

long MDecoderClass::freeBuffer()
{
    if (m_pFrame)
        avcodec_free_frame(&m_pFrame);
    if (m_pFrameRGB)
        avcodec_free_frame(&m_pFrameRGB);
    if (m_pFormatCtx)
        avformat_free_context(m_pFormatCtx);
    if (m_buffer)
        av_free(m_buffer);
    m_pFrame = NULL;
    m_pFrameRGB = NULL;
    m_pFormatCtx = NULL;
    m_pCodecCtx = NULL;
    m_pCodec = NULL;
    m_buffer = NULL;

    return 0;
}

long MDecoderClass::threadTerminate()
{
    this->m_stop = true;
    if (this->m_pause)
        this->m_pause = false;
    WaitForSingleObject(m_decodeThreadHandle, INFINITE);
    CloseHandle(m_decodeThreadHandle);
    m_decodeThreadHandle = NULL;
    return 0;
}

long MDecoderClass::setDisplayFun(MDisplay display,     MoveToThreadCB moveToThread,
                                  RemoveFromThreadCB removeFromThread, void *pContext)
{
    if (!display)
        return 1;
    this->m_displayFun = display;
    this->m_moveToThread = moveToThread;
    this->m_removeFromThread = removeFromThread;
    m_pContext = pContext;
    return 0;
}

long MDecoderClass::openDecoder(const char *filename, int &_Width, int &_Height)
{
    threadTerminate();
    freeBuffer();

    packet_queue_init(&this->videoq);

    m_pFormatCtx = avformat_alloc_context();
    int ret = avformat_open_input(&m_pFormatCtx, filename, NULL, NULL);
    if(ret !=0 )
        return 1; // ���ܴ򿪴��ļ�

    if(av_find_stream_info(m_pFormatCtx)<0)
        return 1;
    av_dump_format(m_pFormatCtx, 0, filename, false);

    uint32_t i;
    // Ѱ�ҵ�һ����Ƶ��videoStream=-1;
    for(i=0; i<m_pFormatCtx->nb_streams; i++)
        if(m_pFormatCtx->streams[i]->codec->codec_type==AVMEDIA_TYPE_VIDEO)
        {
            videoStream=i;
            break;
        }
    if(videoStream==-1)
        return 1;
    m_pCodecCtx = m_pFormatCtx->streams[videoStream]->codec;
    m_pCodec = avcodec_find_decoder(m_pCodecCtx->codec_id);
    if(m_pCodec==NULL)
        return 1;

    if(m_pCodec->capabilities & CODEC_CAP_TRUNCATED)
        m_pCodecCtx->flags|=CODEC_FLAG_TRUNCATED;

    if(avcodec_open(m_pCodecCtx, m_pCodec)<0)
        return 1;

    m_pFrame = avcodec_alloc_frame();
    m_pFrameRGB = avcodec_alloc_frame();
    m_numBytes =avpicture_get_size(AV_PIX_FMT_RGB24, m_pCodecCtx->width,  m_pCodecCtx->height);
    m_buffer=(uint8_t *)av_malloc(m_numBytes*sizeof(uint8_t));

    avpicture_fill((AVPicture *)m_pFrameRGB,m_buffer, AV_PIX_FMT_RGB24,m_pCodecCtx->width, m_pCodecCtx->height);
    _Width = m_pCodecCtx->width;
    _Height = m_pCodecCtx->height;
    return 0;
}

long MDecoderClass::play()
{
    if (!m_pFormatCtx)
        return 0;

    if (m_decodeThreadHandle)
    {
        threadTerminate();
    }
    this->m_stop = false;
    this->m_pause = false;
    m_decodeThreadHandle = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)DecodeThread,(PVOID)this,0,NULL);

    return 0;
}

long MDecoderClass::pause()
{
    if (!this->m_pause)
        this->m_pause = true;
    else
        this->m_pause = false;

    return 0;
}

long MDecoderClass::stop()
{
    if (this->m_pause)
        this->m_pause = false;
    this->m_stop = true;

    return 0;
}
