#ifndef MDECODERCLASS_H
#define MDECODERCLASS_H

#ifndef INT64_C
#define INT64_C
#define UINT64_C
#endif

#ifdef __cplusplus
extern "C" {
#endif
#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
#include "libswscale/swscale.h"
#ifdef __cplusplus
}
#endif

#include <Windows.h>
#include <WinDef.h>
#include <Winbase.h>

#include "GlobalHeader.h"

#define VIDEO_PICTURE_QUEUE_SIZE 4
#define AUDIO_BUFFER_SIZE 1024
#define SAMPLE_ARRAY_SIZE (8*65536)
#define DISPLAYBUFZISE (1920*1080*4)

typedef void (*MDisplay)(unsigned char *pBuf, int bufSize ,int Width, int Height, void * pContext);
typedef void (*MoveToThreadCB)(void * pContext);
typedef void (*RemoveFromThreadCB)(void * pContext);

typedef struct PacketQueue {
    AVPacketList *first_pkt, *last_pkt;
    int nb_packets;
    int size;
    int abort_request;
} PacketQueue;

typedef struct VideoPicture {
    double pts;             // presentation timestamp for this picture
    int64_t pos;            // byte position in file
    int skip;
    int width, height; /* source height & width */
    AVRational sample_aspect_ratio;
    int allocated;
    int reallocate;

#if CONFIG_AVFILTER
    AVFilterBufferRef *picref;
#endif
} VideoPicture;

class MDecoderClass
{
public:
    MDecoderClass();
    ~MDecoderClass();

public:
    long freeBuffer();
    long threadTerminate();
    long setDisplayFun(MDisplay display, MoveToThreadCB moveToThread, RemoveFromThreadCB removeFromThread, void *pContext);
    long openDecoder(const char *filename, int &_Width, int &_Height);
    long play();
    long pause();
    long stop();

public:
    int decoder_reorder_pts;
    AVPacket flush_pkt;

    AVFormatContext *m_pFormatCtx;
    uint32_t             videoStream;
    AVCodecContext  *m_pCodecCtx;
    AVCodec         *m_pCodec;
    AVFrame         *m_pFrame;
    AVFrame         *m_pFrameRGB;
    AVPacket        packet;
    int m_numBytes;
    uint8_t         *m_buffer;
    struct SwsContext *img_convert_ctx;
    HANDLE  m_decodeThreadHandle;
    bool m_pause;
    bool m_stop;

    MDisplay m_displayFun;
    MoveToThreadCB m_moveToThread;
    RemoveFromThreadCB m_removeFromThread;
    void *m_pContext;

    double frame_timer;
    double frame_last_pts;
    double frame_last_duration;
    double frame_last_dropped_pts;
    double frame_last_returned_time;
    double frame_last_filter_delay;
    int64_t frame_last_dropped_pos;
    double video_clock;             // pts of last decoded frame / predicted pts of next decoded frame
    int video_stream;
    AVStream *video_st;
    double video_current_pts;       // current displayed pts (different from video_clock if frame fifos are used)
    double video_current_pts_drift; // video_current_pts - time (av_gettime) at which we updated video_current_pts - used to have running video pts
    int64_t video_current_pos;      // current displayed file pos
    VideoPicture pictq[VIDEO_PICTURE_QUEUE_SIZE];
    PacketQueue videoq;
};

#endif // MDECODERCLASS_H
